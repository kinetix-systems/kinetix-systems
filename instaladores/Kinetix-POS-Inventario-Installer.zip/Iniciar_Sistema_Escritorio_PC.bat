@echo off
chcp 65001 >nul
title Kinetix POS v3.0 - Lanzador Oficial

set "APP_FILE=Kinetix_POS_Facturacion_Inventario.html"
set "APP_PATH=%~dp0%APP_FILE%"

:: Caso 1: Archivo presente en la misma carpeta (descomprimido normal)
if exist "%APP_PATH%" goto LAUNCH_BROWSER

:: Caso 2: Verificar si ya esta instalado en LocalAppData
set "LOCAL_INSTALL=%LOCALAPPDATA%\Kinetix Systems\Kinetix POS\%APP_FILE%"
if exist "%LOCAL_INSTALL%" (
    set "APP_PATH=%LOCAL_INSTALL%"
    goto LAUNCH_BROWSER
)

:: Caso 3: Verificar si el instalador exe esta presente en la misma carpeta
if exist "%~dp0Instalador_Kinetix_POS.exe" (
    echo Iniciando Instalador Oficial Kinetix POS...
    start "" "%~dp0Instalador_Kinetix_POS.exe"
    exit
)

:: Caso 4: Se abrio directamente dentro de WinRAR / Temp sin descomprimir
cls
echo ========================================================================
echo                 ATENCION: ARCHIVO EN MODO TEMPORAL
echo ========================================================================
echo.
echo  Has abierto este archivo directamente desde WinRAR o un archivo ZIP
echo  sin descomprimir la carpeta previamente.
echo.
echo  Para instalar y usar Kinetix POS correctamente en tu PC:
echo.
echo    1. Haz clic en el boton "Extraer en" de WinRAR y extrae la carpeta.
echo    2. O ejecuta directamente "Instalador_Kinetix_POS.exe".
echo.
echo ========================================================================
echo Presiona cualquier tecla para salir...
pause >nul
exit

:LAUNCH_BROWSER
set "CHROME_1=C:\Program Files\Google\Chrome\Application\chrome.exe"
set "CHROME_2=C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
set "CHROME_3=%LocalAppData%\Google\Chrome\Application\chrome.exe"
set "EDGE_1=C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
set "EDGE_2=C:\Program Files\Microsoft\Edge\Application\msedge.exe"
set "BRAVE_1=C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe"

if exist "%CHROME_1%" (
    start "" /max "%CHROME_1%" --start-maximized --app="file:///%APP_PATH%"
    exit
)
if exist "%CHROME_2%" (
    start "" /max "%CHROME_2%" --start-maximized --app="file:///%APP_PATH%"
    exit
)
if exist "%CHROME_3%" (
    start "" /max "%CHROME_3%" --start-maximized --app="file:///%APP_PATH%"
    exit
)
if exist "%EDGE_1%" (
    start "" /max "%EDGE_1%" --start-maximized --app="file:///%APP_PATH%"
    exit
)
if exist "%EDGE_2%" (
    start "" /max "%EDGE_2%" --start-maximized --app="file:///%APP_PATH%"
    exit
)
if exist "%BRAVE_1%" (
    start "" /max "%BRAVE_1%" --start-maximized --app="file:///%APP_PATH%"
    exit
)

:: Navegador por defecto
start "" /max "%APP_PATH%"
exit
